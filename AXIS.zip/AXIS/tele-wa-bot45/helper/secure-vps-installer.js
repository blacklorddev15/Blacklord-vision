'use strict';

const crypto = require('crypto');
const https = require('https');
const net = require('net');

const FORM_PATH = '/secure-panel-install';
const TOKEN_TTL_MS = 10 * 60 * 1000;
const INSTALLER_VERSION = 'v1.4.0';
const INSTALLER_URL = `https://raw.githubusercontent.com/pterodactyl-installer/pterodactyl-installer/${INSTALLER_VERSION}/install.sh`;
const THEME_REPOSITORY = 'blacklorddev15/Blacklord-vision';
const THEME_RAW_BASE = 'https://raw.githubusercontent.com/blacklorddev15/Blacklord-vision/main/theme';
const THEME_NAME = 'Blacklord Signed-in Theme';
const MAX_INSTALL_MS = 45 * 60 * 1000;
const MAX_THEME_FILE_BYTES = 6 * 1024 * 1024;
const MAX_THEME_TOTAL_BYTES = 10 * 1024 * 1024;
const ALLOWED_THEME_FILES = Object.freeze([
  'install-theme.py',
  'assets/james-admin.css',
  'assets/james-signed-in.css',
  'assets/james-store-background.jpg',
  'assets/panel-theme.css',
  'assets/panel-theme.js',
  'panel/PanelThemeController.php',
  'panel/panel-theme.blade.php',
  'patches/company-name-only-settings-provider.patch',
]);
const VALID_ACTIONS = new Set(['panel', 'wings', 'theme']);

class InstallerError extends Error {
  constructor(code) {
    super(code);
    this.name = 'InstallerError';
    this.code = code;
  }
}

function digestToken(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

function createInstallTokenStore({ ttlMs = TOKEN_TTL_MS, now = Date.now } = {}) {
  const tokens = new Map();
  function prune() {
    const time = now();
    for (const [hash, record] of tokens) if (record.expiresAt <= time) tokens.delete(hash);
  }
  function peek(token) {
    if (!/^[a-f0-9]{64}$/i.test(String(token || ''))) return null;
    const hash = digestToken(token);
    const record = tokens.get(hash);
    if (!record) return null;
    if (record.expiresAt <= now()) {
      tokens.delete(hash);
      return null;
    }
    return { ownerId: record.ownerId, action: record.action, expiresAt: record.expiresAt };
  }
  return {
    issue(ownerId, action) {
      if (!VALID_ACTIONS.has(action)) throw new InstallerError('INVALID_INSTALL_ACTION');
      prune();
      const token = crypto.randomBytes(32).toString('hex');
      const expiresAt = now() + ttlMs;
      tokens.set(digestToken(token), { ownerId: String(ownerId), action, expiresAt });
      return { token, expiresAt };
    },
    peek,
    consume(token, ownerId, action) {
      const record = peek(token);
      if (!record || record.ownerId !== String(ownerId) || (action && record.action !== action)) return false;
      tokens.delete(digestToken(token));
      return true;
    },
    size() {
      prune();
      return tokens.size;
    },
  };
}

function buildInstallFormUrl(baseUrl, token, action) {
  let base;
  try {
    base = new URL(baseUrl);
  } catch {
    throw new InstallerError('INSTALL_FORM_URL_INVALID');
  }
  if (base.protocol !== 'https:' || base.username || base.password || base.search || base.hash || !VALID_ACTIONS.has(action)) {
    throw new InstallerError('INSTALL_FORM_URL_INVALID');
  }
  const link = new URL(FORM_PATH, base.origin);
  link.searchParams.set('action', action);
  link.hash = String(token);
  return link.toString();
}

function isPublicIPv4(host) {
  if (net.isIP(host) !== 4) return false;
  const [a, b, c, d] = host.split('.').map(Number);
  if ([a, b, c, d].some(part => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  if (a === 0 || a === 10 || a === 127 || a >= 224) return false;
  if (a === 100 && b >= 64 && b <= 127) return false;
  if (a === 169 && b === 254) return false;
  if (a === 172 && b >= 16 && b <= 31) return false;
  if (a === 192 && (b === 0 || b === 168)) return false;
  if (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100))) return false;
  if ((a === 192 && b === 88 && c === 99) || (a === 203 && b === 0 && c === 113)) return false;
  if (a === 255) return false;
  return true;
}

function isValidHostname(hostname) {
  if (typeof hostname !== 'string' || hostname.length > 253 || net.isIP(hostname)) return false;
  const labels = hostname.toLowerCase().split('.');
  if (labels.length < 2) return false;
  return labels.every(label => label.length >= 1 && label.length <= 63 && /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(label));
}

function safeText(value, maxLength) {
  const text = String(value ?? '').trim();
  if (!text || text.length > maxLength || /[\u0000-\u001f\u007f]/.test(text)) return null;
  return text;
}

function validateSshDetails(body) {
  const host = safeText(body.ip, 64);
  const sshUsername = safeText(body.ssh_username, 32);
  const sshPortRaw = safeText(body.ssh_port, 5);
  const sshPort = Number(sshPortRaw);
  const sshPassword = String(body.ssh_password ?? '');
  if (!host || !isPublicIPv4(host)) throw new InstallerError('INVALID_PUBLIC_IPV4');
  if (!sshUsername || !/^[a-z_][a-z0-9_-]{0,31}$/i.test(sshUsername)) throw new InstallerError('INVALID_SSH_USERNAME');
  if (!Number.isInteger(sshPort) || sshPort < 1 || sshPort > 65535) throw new InstallerError('INVALID_SSH_PORT');
  if (!sshPassword || sshPassword.length > 256 || /[\u0000-\u001f\u007f]/.test(sshPassword)) throw new InstallerError('INVALID_SSH_PASSWORD');
  return { host, sshUsername, sshPort, sshPassword };
}

function validatePanelInstallInput(body = {}) {
  const ssh = validateSshDetails(body);
  const panelDomain = safeText(body.panel_domain, 253)?.toLowerCase();
  const contactEmail = safeText(body.contact_email, 254);
  const adminEmail = safeText(body.admin_email, 254);
  const adminUsername = safeText(body.admin_username, 32);
  const adminFirstName = safeText(body.admin_first_name, 50);
  const adminLastName = safeText(body.admin_last_name, 50);
  const adminPassword = String(body.admin_password ?? '');

  if (!panelDomain || !isValidHostname(panelDomain)) throw new InstallerError('INVALID_PANEL_DOMAIN');
  if (!contactEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(contactEmail)) throw new InstallerError('INVALID_CONTACT_EMAIL');
  if (!adminEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(adminEmail)) throw new InstallerError('INVALID_ADMIN_EMAIL');
  if (!adminUsername || !/^[a-z0-9_]{3,32}$/i.test(adminUsername)) throw new InstallerError('INVALID_ADMIN_USERNAME');
  if (!adminFirstName || !/^[\p{L}][\p{L} .'-]{0,49}$/u.test(adminFirstName) ||
      !adminLastName || !/^[\p{L}][\p{L} .'-]{0,49}$/u.test(adminLastName)) throw new InstallerError('INVALID_ADMIN_NAME');
  if (adminPassword.length < 12 || adminPassword.length > 128 || /[\u0000-\u001f\u007f]/.test(adminPassword) ||
      !/[A-Z]/.test(adminPassword) || !/[a-z]/.test(adminPassword) || !/[0-9]/.test(adminPassword)) {
    throw new InstallerError('INVALID_ADMIN_PASSWORD');
  }
  if (body.confirm_fresh_server !== 'on') throw new InstallerError('FRESH_SERVER_CONFIRMATION_REQUIRED');
  return {
    ...ssh, panelDomain, contactEmail, adminEmail, adminUsername, adminFirstName, adminLastName, adminPassword,
    configureFirewall: body.configure_firewall === 'on',
  };
}

function validateWingsInstallInput(body = {}) {
  const ssh = validateSshDetails(body);
  const nodeDomain = safeText(body.node_domain, 253)?.toLowerCase();
  const contactEmail = safeText(body.contact_email, 254);
  const wingsConfig = String(body.wings_config ?? '');
  if (!nodeDomain || !isValidHostname(nodeDomain)) throw new InstallerError('INVALID_NODE_DOMAIN');
  if (!contactEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(contactEmail)) throw new InstallerError('INVALID_CONTACT_EMAIL');
  if (!wingsConfig.trim() || Buffer.byteLength(wingsConfig, 'utf8') > 64 * 1024 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(wingsConfig)) {
    throw new InstallerError('INVALID_WINGS_CONFIG');
  }
  if (!/^\s*api\s*:/m.test(wingsConfig) || !/^\s*token\s*:/m.test(wingsConfig)) {
    throw new InstallerError('INVALID_WINGS_CONFIG');
  }
  if (body.confirm_node_created !== 'on') throw new InstallerError('NODE_CONFIRMATION_REQUIRED');
  return { ...ssh, nodeDomain, contactEmail, wingsConfig, configureFirewall: body.configure_firewall === 'on' };
}

function validateThemeInstallInput(body = {}) {
  const ssh = validateSshDetails(body);
  const panelRoot = safeText(body.panel_root || '/var/www/pterodactyl', 512);
  if (!panelRoot || !/^\/(?:[A-Za-z0-9._-]+\/)*[A-Za-z0-9._-]+$/.test(panelRoot) ||
      panelRoot.split('/').some(part => part === '.' || part === '..')) {
    throw new InstallerError('INVALID_PANEL_ROOT');
  }
  if (body.confirm_theme_install !== 'on') throw new InstallerError('THEME_INSTALL_CONFIRMATION_REQUIRED');
  return { ...ssh, panelRoot };
}

function shellQuote(value) {
  return `'${String(value).replace(/'/g, "'\\''")}'`;
}

function buildPanelInstallScript(details) {
  const firewall = details.configureFirewall ? 'true' : 'false';
  return [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    `INSTALLER_URL=${shellQuote(INSTALLER_URL)}`,
    'installer_file="$(mktemp)"',
    'trap \'rm -f "$installer_file"\' EXIT',
    'curl --fail --location --silent --show-error "$INSTALLER_URL" --output "$installer_file"',
    `export FQDN=${shellQuote(details.panelDomain)}`,
    `export email=${shellQuote(details.contactEmail)}`,
    `export user_email=${shellQuote(details.adminEmail)}`,
    `export user_username=${shellQuote(details.adminUsername)}`,
    `export user_firstname=${shellQuote(details.adminFirstName)}`,
    `export user_lastname=${shellQuote(details.adminLastName)}`,
    `export user_password=${shellQuote(details.adminPassword)}`,
    `export CONFIGURE_LETSENCRYPT=true CONFIGURE_FIREWALL=${firewall} ASSUME_SSL=true timezone=UTC`,
    'bash "$installer_file" <<< \'0\'',
    ...(details.configureFirewall ? [`if command -v ufw >/dev/null 2>&1; then ufw allow ${details.sshPort}/tcp >/dev/null 2>&1 || true; fi`] : []),
    'unset user_password',
    '',
  ].join('\n');
}

function buildWingsInstallScript(details) {
  const firewall = details.configureFirewall ? 'true' : 'false';
  const configBase64 = Buffer.from(details.wingsConfig, 'utf8').toString('base64');
  return [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    `INSTALLER_URL=${shellQuote(INSTALLER_URL)}`,
    'installer_file="$(mktemp)"',
    'trap \'rm -f "$installer_file"\' EXIT',
    'curl --fail --location --silent --show-error "$INSTALLER_URL" --output "$installer_file"',
    `export FQDN=${shellQuote(details.nodeDomain)}`,
    `export EMAIL=${shellQuote(details.contactEmail)}`,
    `export CONFIGURE_LETSENCRYPT=true CONFIGURE_FIREWALL=${firewall}`,
    'bash "$installer_file" <<< \'1\'',
    ...(details.configureFirewall ? [`if command -v ufw >/dev/null 2>&1; then ufw allow ${details.sshPort}/tcp >/dev/null 2>&1 || true; fi`] : []),
    'install -d -o root -g root -m 0750 /etc/pterodactyl',
    `printf '%s' ${shellQuote(configBase64)} | base64 --decode > /etc/pterodactyl/config.yml`,
    'chown root:root /etc/pterodactyl/config.yml',
    'chmod 0600 /etc/pterodactyl/config.yml',
    'systemctl enable --now wings',
    'systemctl is-active --quiet wings',
    '',
  ].join('\n');
}

function validateThemeManifest(raw) {
  let manifest;
  try {
    manifest = Buffer.isBuffer(raw) || raw instanceof Uint8Array ? JSON.parse(Buffer.from(raw).toString('utf8')) : raw;
  } catch {
    throw new InstallerError('THEME_MANIFEST_INVALID');
  }
  if (!manifest || manifest.name !== THEME_NAME || manifest.repository !== THEME_REPOSITORY ||
      typeof manifest.version !== 'string' || !/^[A-Za-z0-9._-]{1,32}$/.test(manifest.version)) {
    throw new InstallerError('THEME_MANIFEST_INVALID');
  }
  if (!manifest.files || typeof manifest.files !== 'object' || Array.isArray(manifest.files)) {
    throw new InstallerError('THEME_MANIFEST_INVALID');
  }
  const keys = Object.keys(manifest.files).sort();
  if (keys.length !== ALLOWED_THEME_FILES.length || keys.some((key, index) => key !== [...ALLOWED_THEME_FILES].sort()[index])) {
    throw new InstallerError('THEME_FILE_LIST_INVALID');
  }
  for (const name of keys) {
    const entry = manifest.files[name];
    if (!entry || typeof entry !== 'object' || !/^[a-f0-9]{64}$/.test(entry.sha256 || '') ||
        !Number.isInteger(entry.size) || entry.size < 0 || entry.size > MAX_THEME_FILE_BYTES) {
      throw new InstallerError('THEME_FILE_METADATA_INVALID');
    }
  }
  return manifest;
}

function downloadHttpsBuffer(url, maxBytes, redirects = 0) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(url); } catch { return reject(new InstallerError('THEME_SOURCE_UNAVAILABLE')); }
    if (parsed.protocol !== 'https:' || parsed.hostname !== 'raw.githubusercontent.com' || parsed.username || parsed.password) {
      return reject(new InstallerError('THEME_SOURCE_URL_REJECTED'));
    }
    const request = https.get(parsed, { headers: { 'User-Agent': 'Blacklord-Vision-Theme-Installer', Accept: 'application/octet-stream' } }, (response) => {
      const status = response.statusCode || 0;
      if ([301, 302, 303, 307, 308].includes(status) && response.headers.location && redirects < 2) {
        const next = new URL(response.headers.location, parsed);
        response.resume();
        if (next.hostname !== 'raw.githubusercontent.com' || next.protocol !== 'https:') {
          return reject(new InstallerError('THEME_SOURCE_URL_REJECTED'));
        }
        return resolve(downloadHttpsBuffer(next.toString(), maxBytes, redirects + 1));
      }
      if (status !== 200) {
        response.resume();
        return reject(new InstallerError('THEME_SOURCE_UNAVAILABLE'));
      }
      const headerSize = Number(response.headers['content-length'] || 0);
      if (headerSize > maxBytes) {
        response.destroy();
        return reject(new InstallerError('THEME_FILE_TOO_LARGE'));
      }
      const chunks = [];
      let size = 0;
      response.on('data', (chunk) => {
        size += chunk.length;
        if (size > maxBytes) {
          response.destroy();
          reject(new InstallerError('THEME_FILE_TOO_LARGE'));
          return;
        }
        chunks.push(chunk);
      });
      response.on('end', () => resolve(Buffer.concat(chunks)));
      response.on('error', () => reject(new InstallerError('THEME_SOURCE_UNAVAILABLE')));
    });
    request.setTimeout(30_000, () => request.destroy(new Error('timeout')));
    request.on('error', () => reject(new InstallerError('THEME_SOURCE_UNAVAILABLE')));
  });
}

async function fetchThemeBundle({ getBuffer = downloadHttpsBuffer, baseUrl = THEME_RAW_BASE } = {}) {
  let base;
  try { base = new URL(baseUrl); } catch { throw new InstallerError('THEME_SOURCE_URL_REJECTED'); }
  if (base.protocol !== 'https:' || base.hostname !== 'raw.githubusercontent.com' ||
      base.pathname !== '/blacklorddev15/Blacklord-vision/main/theme') {
    throw new InstallerError('THEME_SOURCE_URL_REJECTED');
  }
  const manifestBuffer = await getBuffer(`${baseUrl}/manifest.json`, 64 * 1024);
  const manifest = validateThemeManifest(manifestBuffer);
  const fileEntries = await Promise.all(Object.keys(manifest.files).map(async (name) => {
    const encodedPath = name.split('/').map(encodeURIComponent).join('/');
    const data = Buffer.from(await getBuffer(`${baseUrl}/${encodedPath}`, MAX_THEME_FILE_BYTES));
    const metadata = manifest.files[name];
    if (data.length !== metadata.size || crypto.createHash('sha256').update(data).digest('hex') !== metadata.sha256) {
      throw new InstallerError('THEME_INTEGRITY_FAILED');
    }
    return [name, data];
  }));
  const totalSize = fileEntries.reduce((sum, [, data]) => sum + data.length, manifestBuffer.length);
  if (totalSize > MAX_THEME_TOTAL_BYTES) throw new InstallerError('THEME_BUNDLE_TOO_LARGE');
  return { manifest, manifestBuffer: Buffer.from(manifestBuffer), files: Object.fromEntries(fileEntries) };
}

function buildThemeInstallScript(details, bundle) {
  if (!details || !bundle || !bundle.manifestBuffer || !bundle.files) throw new InstallerError('THEME_BUNDLE_INVALID');
  const manifest = validateThemeManifest(bundle.manifestBuffer);
  if (manifest.version !== bundle.manifest.version) throw new InstallerError('THEME_BUNDLE_INVALID');
  const names = Object.keys(bundle.files).sort();
  const expectedNames = [...ALLOWED_THEME_FILES].sort();
  if (names.length !== expectedNames.length || names.some((name, index) => name !== expectedNames[index])) {
    throw new InstallerError('THEME_BUNDLE_INVALID');
  }
  const entries = [['manifest.json', Buffer.from(bundle.manifestBuffer)], ...names.map((name) => [name, Buffer.from(bundle.files[name])])];
  for (const [name, data] of entries) {
    if (name !== 'manifest.json') {
      const metadata = manifest.files[name];
      if (!metadata || data.length !== metadata.size || crypto.createHash('sha256').update(data).digest('hex') !== metadata.sha256) {
        throw new InstallerError('THEME_INTEGRITY_FAILED');
      }
    }
  }
  const lines = [
    '#!/usr/bin/env bash',
    'set -euo pipefail',
    'work="$(mktemp -d /tmp/blacklord-theme.XXXXXX)"',
    'trap \'rm -rf "$work"\' EXIT',
    'mkdir -p "$work/theme"',
  ];
  for (const [name, data] of entries) {
    const directory = name.includes('/') ? name.slice(0, name.lastIndexOf('/')) : '';
    if (directory) lines.push(`mkdir -p "$work/theme/${directory}"`);
    const encoded = data.toString('base64');
    lines.push(`printf '%s' ${shellQuote(encoded)} | base64 --decode > "$work/theme/${name}"`);
  }
  lines.push(
    'chmod 0700 "$work/theme/install-theme.py"',
    `python3 "$work/theme/install-theme.py" ${shellQuote(details.panelRoot)} "$work/theme" ${shellQuote(manifest.version)}`,
    '',
  );
  return lines.join('\n');
}

function renderInstallForm(nonce, action) {
  if (!VALID_ACTIONS.has(action)) throw new InstallerError('INVALID_INSTALL_ACTION');
  const panelFields = `<div class="grid">
<div><label for="ip">VPS public IPv4</label><input id="ip" name="ip" inputmode="decimal" required maxlength="64" placeholder="Your VPS IPv4"></div>
<div><label for="ssh_username">SSH username</label><input id="ssh_username" name="ssh_username" autocomplete="username" required maxlength="32" value="root"></div>
<div><label for="ssh_port">SSH port</label><input id="ssh_port" name="ssh_port" type="number" min="1" max="65535" value="22" required></div>
<div><label for="ssh_password">SSH password</label><input id="ssh_password" name="ssh_password" type="password" autocomplete="current-password" required maxlength="256"></div>
<div><label for="panel_domain">Panel domain (DNS A record must point to this VPS)</label><input id="panel_domain" name="panel_domain" required maxlength="253" placeholder="panel.example.com"></div>
<div><label for="contact_email">Let's Encrypt contact email</label><input id="contact_email" name="contact_email" type="email" autocomplete="email" required maxlength="254"></div>
<div><label for="admin_email">Panel admin email</label><input id="admin_email" name="admin_email" type="email" autocomplete="email" required maxlength="254"></div>
<div><label for="admin_username">Panel admin username</label><input id="admin_username" name="admin_username" autocomplete="username" required minlength="3" maxlength="32"></div>
<div><label for="admin_first_name">Admin first name</label><input id="admin_first_name" name="admin_first_name" autocomplete="given-name" required maxlength="50"></div>
<div><label for="admin_last_name">Admin last name</label><input id="admin_last_name" name="admin_last_name" autocomplete="family-name" required maxlength="50"></div>
<div><label for="admin_password">Panel admin password</label><input id="admin_password" name="admin_password" type="password" autocomplete="new-password" required minlength="12" maxlength="128"></div>
</div>
<div class="checks"><label><input type="checkbox" name="configure_firewall">Configure the server firewall to open installer ports</label>
<label><input type="checkbox" name="confirm_fresh_server" required> I control this fresh VPS and approve installing the Panel and required services</label></div>
<button type="submit">Start Panel installation</button>
<p><small>Panel installation stops here. After it succeeds, visit the Panel, create a node, then return to Telegram and choose Create Wings. The SSH password is discarded after this attempt.</small></p>`;
  const wingsFields = `<div class="grid">
<div><label for="ip">VPS public IPv4</label><input id="ip" name="ip" inputmode="decimal" required maxlength="64" placeholder="Your VPS IPv4"></div>
<div><label for="ssh_username">SSH username</label><input id="ssh_username" name="ssh_username" autocomplete="username" required maxlength="32" value="root"></div>
<div><label for="ssh_port">SSH port</label><input id="ssh_port" name="ssh_port" type="number" min="1" max="65535" value="22" required></div>
<div><label for="ssh_password">SSH password</label><input id="ssh_password" name="ssh_password" type="password" autocomplete="current-password" required maxlength="256"></div>
<div><label for="node_domain">Wings node domain (DNS A record must point to this VPS)</label><input id="node_domain" name="node_domain" required maxlength="253" placeholder="node.example.com"></div>
<div><label for="contact_email">Let's Encrypt contact email</label><input id="contact_email" name="contact_email" type="email" autocomplete="email" required maxlength="254"></div>
</div>
<label for="wings_config">Paste the complete config.yml from the Panel's Node → Configuration tab</label>
<textarea id="wings_config" name="wings_config" rows="16" spellcheck="false" autocomplete="off" required maxlength="65536" placeholder="Paste the complete generated Wings config.yml here"></textarea>
<div class="checks"><label><input type="checkbox" name="configure_firewall">Configure the server firewall for Wings ports</label>
<label><input type="checkbox" name="confirm_node_created" required> I created the node in the Panel and approve installing Wings and writing this config to /etc/pterodactyl/config.yml on the VPS</label></div>
<button type="submit">Install Wings and apply node config</button>
<p><small>The config contains node credentials. It is sent only through this HTTPS form, is not stored on the bot host or in its database, and is cleared from memory after the attempt. The required runtime file is written only on the target VPS.</small></p>`;
  const themeFields = `<div class="grid">
<div><label for="ip">Panel VPS public IPv4</label><input id="ip" name="ip" inputmode="decimal" required maxlength="64" placeholder="Your Panel VPS IPv4"></div>
<div><label for="ssh_username">SSH username</label><input id="ssh_username" name="ssh_username" autocomplete="username" required maxlength="32" value="root"></div>
<div><label for="ssh_port">SSH port</label><input id="ssh_port" name="ssh_port" type="number" min="1" max="65535" value="22" required></div>
<div><label for="ssh_password">SSH password</label><input id="ssh_password" name="ssh_password" type="password" autocomplete="current-password" required maxlength="256"></div>
<div><label for="panel_root">Pterodactyl Panel directory</label><input id="panel_root" name="panel_root" autocomplete="off" required maxlength="512" value="/var/www/pterodactyl"></div>
</div>
<div class="checks"><label><input type="checkbox" name="confirm_theme_install" required> I control this Panel and approve installing the latest Blacklord theme from the repository</label></div>
<button type="submit">Install latest repo theme</button>
<p><small>The bot downloads a SHA-256-checksum-verified package from the Blacklord-Vision repository, then sends it over SSH. A private backup is created outside the web root. Existing Company Name, background URL, and colors are preserved; authentication/login templates and login assets are not changed.</small></p>`;
  const title = action === 'panel' ? 'Install Pterodactyl Panel' : action === 'wings' ? 'Create Wings' : 'Install Blacklord Theme';
  const intro = action === 'panel'
    ? 'This one-time form installs the Panel on a fresh VPS. The bot will stop after the Panel succeeds and send you the Panel URL.'
    : action === 'wings'
      ? 'Use this only after you manually create a node in the Panel. The bot will install Wings, write the generated configuration to the VPS, and start the Wings service.'
      : 'This one-time form installs the latest signed-in theme from the Blacklord-Vision repository on an existing Panel.';
  const fields = action === 'panel' ? panelFields : action === 'wings' ? wingsFields : themeFields;
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title>
<style nonce="${nonce}">:root{color-scheme:dark;font-family:system-ui,sans-serif}body{margin:0;background:#0c1118;color:#f2f5f7}main{max-width:760px;margin:24px auto;padding:20px}section{background:#151d27;border:1px solid #334151;border-radius:14px;padding:22px}h1{font-size:1.45rem}p,small{color:#c0cad4;line-height:1.5}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}label{display:block;font-weight:600;margin:12px 0 5px}input,textarea{box-sizing:border-box;width:100%;padding:11px;border-radius:8px;border:1px solid #596878;background:#0b1118;color:#fff}textarea{font-family:monospace;resize:vertical}input[type=checkbox]{width:auto;margin-right:8px}button{margin-top:18px;padding:12px 18px;border:0;border-radius:8px;background:#c5e447;color:#111;font-weight:700;cursor:pointer}.notice{padding:12px;background:#202b36;border-radius:8px}.checks{margin-top:14px}.error{color:#ffb7b7}@media(max-width:600px){main{padding:12px}.grid{grid-template-columns:1fr}}</style></head>
<body><main><section><h1>${title}</h1><p>${intro}</p><p class="notice">Use this form only on a private HTTPS link from the configured owner's Telegram chat. Do not send SSH passwords or node configuration in Telegram.</p>
<div id="link-error" class="error" hidden>This form link is missing or invalid. Re-open the latest link from the owner's private Telegram chat.</div>
<form id="install-form" method="post" action="${FORM_PATH}?action=${action}" autocomplete="off">
<input type="hidden" name="token" id="form-token"><input type="hidden" name="action" value="${action}">
${fields}</form></section></main>
<script nonce="${nonce}">(()=>{const token=location.hash.slice(1);history.replaceState(null,document.title,location.pathname+location.search);if(!/^[a-f0-9]{64}$/i.test(token)){document.getElementById('install-form').hidden=true;document.getElementById('link-error').hidden=false;return;}document.getElementById('form-token').value=token;})();</script>
</body></html>`;
}

function renderSubmittedPage(action) {
  const label = action === 'wings' ? 'Wings installation' : action === 'theme' ? 'Theme installation' : 'Panel installation';
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installation started</title><body style="font:16px system-ui;background:#0c1118;color:#f2f5f7;padding:2rem"><h1>${label} started</h1><p>Return to the owner's Telegram chat for status. This page does not display or retain your form values.</p></body></html>`;
}

function clearSensitiveDetails(details) {
  for (const key of ['sshPassword', 'adminPassword', 'wingsConfig']) {
    if (Object.prototype.hasOwnProperty.call(details, key)) details[key] = '';
  }
}

function runInstallerOverSSH(details, ClientClass, action = 'panel', themeBundle = null) {
  if (typeof ClientClass !== 'function' || !VALID_ACTIONS.has(action)) return Promise.reject(new InstallerError('INVALID_INSTALL_ACTION'));
  let script;
  try {
    script = action === 'wings'
      ? buildWingsInstallScript(details)
      : action === 'theme'
        ? buildThemeInstallScript(details, themeBundle)
        : buildPanelInstallScript(details);
  } catch {
    clearSensitiveDetails(details);
    return Promise.reject(new InstallerError('INSTALL_SCRIPT_FAILED'));
  }
  let sshPassword = details.sshPassword;
  let sudoPassword = '';
  let connectConfig = null;
  return new Promise((resolve, reject) => {
    const conn = new ClientClass();
    let settled = false;
    let timer;
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      script = '';
      sshPassword = '';
      sudoPassword = '';
      if (connectConfig) connectConfig.password = '';
      try { if (conn.config) conn.config.password = ''; } catch {}
      clearSensitiveDetails(details);
      if (themeBundle) {
        if (Buffer.isBuffer(themeBundle.manifestBuffer)) themeBundle.manifestBuffer.fill(0);
        if (themeBundle.files && typeof themeBundle.files === 'object') {
          for (const data of Object.values(themeBundle.files)) if (Buffer.isBuffer(data)) data.fill(0);
        }
      }
      try { conn.end(); } catch {}
      if (error) reject(error); else resolve(result);
    };

    timer = setTimeout(() => finish(new InstallerError('INSTALL_TIMEOUT')), MAX_INSTALL_MS);
    conn.on('ready', () => {
      try { if (conn.config) conn.config.password = ''; } catch {}
      const command = details.sshUsername === 'root' ? 'bash -s' : 'sudo -S -p "" bash -s';
      if (details.sshUsername !== 'root') sudoPassword = sshPassword;
      sshPassword = '';
      details.sshPassword = '';
      conn.exec(command, { pty: false }, (err, stream) => {
        if (err) return finish(new InstallerError('SSH_EXEC_FAILED'));
        stream.on('data', () => {});
        if (stream.stderr) stream.stderr.on('data', () => {});
        stream.on('error', () => finish(new InstallerError('SSH_STREAM_FAILED')));
        stream.on('close', (code, signal) => {
          if (code === 0) finish(null, { exitCode: 0, action });
          else finish(new InstallerError(signal ? 'INSTALL_TERMINATED' : 'INSTALL_FAILED'));
        });
        const input = details.sshUsername === 'root' ? script : `${sudoPassword}\n${script}`;
        sudoPassword = '';
        clearSensitiveDetails(details);
        try {
          stream.end(input);
          script = '';
        } catch {
          finish(new InstallerError('SSH_STREAM_FAILED'));
        }
      });
    });
    conn.on('error', () => finish(new InstallerError('SSH_CONNECTION_FAILED')));
    try {
      connectConfig = {
        host: details.host,
        port: details.sshPort,
        username: details.sshUsername,
        password: sshPassword,
        readyTimeout: 20_000,
        keepaliveInterval: 10_000,
        keepaliveCountMax: 3,
      };
      conn.connect(connectConfig);
    } catch {
      finish(new InstallerError('SSH_CONNECTION_FAILED'));
    }
  });
}

module.exports = {
  FORM_PATH,
  TOKEN_TTL_MS,
  INSTALLER_VERSION,
  THEME_REPOSITORY,
  THEME_RAW_BASE,
  ALLOWED_THEME_FILES,
  InstallerError,
  createInstallTokenStore,
  buildInstallFormUrl,
  isPublicIPv4,
  isValidHostname,
  validatePanelInstallInput,
  validateWingsInstallInput,
  validateThemeInstallInput,
  shellQuote,
  buildPanelInstallScript,
  buildWingsInstallScript,
  validateThemeManifest,
  fetchThemeBundle,
  buildThemeInstallScript,
  renderInstallForm,
  renderSubmittedPage,
  runInstallerOverSSH,
};
