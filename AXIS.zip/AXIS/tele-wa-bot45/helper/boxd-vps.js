'use strict';

const path = require('path');
const { domainToASCII } = require('url');
const { isIPv4 } = require('net');

const GRPC_ENDPOINT = 'boxd.sh:9443';
const AUTH_ENDPOINT = 'https://app.boxd.sh/api/v1/auth/token';
const PROTO_PATH = path.join(__dirname, 'boxd-create-vm.proto');

// Boxd's published rate card (EUR, excluding VAT). The public protobuf
// currently documents 1/4, 2/8 and 4/16 size classes; 8/32 is intentionally
// not offered here because the current API schema and rate page differ.
const BOXD_PLANS = Object.freeze({
  '1': Object.freeze({ vcpu: 1, memoryGiB: 4, memoryBytes: 4 * 1024 ** 3, maxHourlyEUR: '€0.10', maxMonthlyEUR: '€69.35' }),
  '2': Object.freeze({ vcpu: 2, memoryGiB: 8, memoryBytes: 8 * 1024 ** 3, maxHourlyEUR: '€0.18', maxMonthlyEUR: '€132.86' }),
  '4': Object.freeze({ vcpu: 4, memoryGiB: 16, memoryBytes: 16 * 1024 ** 3, maxHourlyEUR: '€0.36', maxMonthlyEUR: '€259.88' }),
});

class BoxdVpsError extends Error {
  constructor(code) {
    super(code);
    this.name = 'BoxdVpsError';
    this.code = code;
  }
}

function getBoxdPlan(planId) {
  const plan = BOXD_PLANS[String(planId)];
  if (!plan) throw new BoxdVpsError('INVALID_PLAN');
  return plan;
}

function normalizeCustomDomain(input) {
  if (typeof input !== 'string') throw new BoxdVpsError('INVALID_DOMAIN');
  const raw = input.trim().replace(/\.$/, '').toLowerCase();
  if (!raw || /[\s/:?#@\\]/.test(raw)) throw new BoxdVpsError('INVALID_DOMAIN');
  const ascii = domainToASCII(raw);
  const labels = ascii.split('.');
  // Require a fully qualified subdomain (for example node.example.com), not
  // an apex: deriving the machine label from an apex would be ambiguous.
  if (!ascii || labels.length < 3 || ascii.length > 253) throw new BoxdVpsError('SUBDOMAIN_REQUIRED');
  if (labels.some((label) => label.length < 1 || label.length > 63 || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label))) {
    throw new BoxdVpsError('INVALID_DOMAIN');
  }
  return Object.freeze({ domain: ascii, machineName: labels[0] });
}

function formatPlanChoice(planId) {
  const plan = getBoxdPlan(planId);
  return `${plan.vcpu} vCPU · ${plan.memoryGiB} GiB — up to ${plan.maxHourlyEUR}/hour`;
}

function formatPlanConfirmation({ domain, machineName, planId }) {
  const plan = getBoxdPlan(planId);
  return [
    'Review this Boxd VPS request before creation:',
    `Domain for DNS: ${domain}`,
    `Boxd machine name / default hostname: ${machineName}.boxd.sh`,
    `Plan: ${plan.vcpu} vCPU, ${plan.memoryGiB} GiB RAM, fixed 100 GiB disk; Frankfurt (fra).`,
    `Published EUR rate-card maximum: ${plan.maxHourlyEUR}/hour and ${plan.maxMonthlyEUR} for 30 days always-on at full CPU, full RAM, and all 100 GiB written. VAT excluded.`,
    'Billing organization: the organization fenced to the server-side BOXD_API_KEY (Boxd API keys are organization-scoped).',
    'Billing is metered by actual active vCPU, RAM in use, and disk written (per second; settled every 15 minutes), so this is not a fixed subscription price. Published rates: €0.039 per active vCPU-hour, €0.012 per GiB-hour of RAM, and €0.00008 per GiB-hour of written disk. Rates are shown in EUR; verify the target organization, currency, and balance in Boxd before confirming. This bot cannot read billing details.',
    'The A-record target is Boxd’s shared proxy IP, not a dedicated machine IP. This will create a metered resource immediately. DNS will not be changed and the custom domain will not be attached automatically; add the records first, then bind/verify the domain in Boxd.',
    'Tap Confirm only if you approve creating this resource under those terms.',
  ].join('\n\n');
}

function normalizeProviderHostname(value) {
  if (typeof value !== 'string' || !value.trim()) throw new BoxdVpsError('BOXD_RESPONSE_MISSING_HOSTNAME');
  const raw = value.trim();
  let hostname;
  try {
    hostname = new URL(raw.includes('://') ? raw : `https://${raw}`).hostname;
  } catch {
    throw new BoxdVpsError('BOXD_RESPONSE_INVALID_HOSTNAME');
  }
  const ascii = domainToASCII(hostname.toLowerCase().replace(/\.$/, ''));
  const labels = ascii.split('.');
  if (!ascii || labels.length < 2 || labels.some((label) => !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label))) {
    throw new BoxdVpsError('BOXD_RESPONSE_INVALID_HOSTNAME');
  }
  return ascii;
}

function buildDnsInstructions({ customDomain, publicIp, boxdUrl }) {
  const domain = typeof customDomain === 'string' ? customDomain : '';
  if (!isIPv4(publicIp)) throw new BoxdVpsError('BOXD_RESPONSE_MISSING_IP');
  const boxdHostname = normalizeProviderHostname(boxdUrl);
  return Object.freeze({
    aRecord: Object.freeze({ name: domain, type: 'A', target: publicIp }),
    cnameRecord: Object.freeze({ name: `*.${domain}`, type: 'CNAME', target: boxdHostname }),
    boxdHostname,
  });
}

function buildCreateRequest({ machineName, planId }) {
  const plan = getBoxdPlan(planId);
  if (typeof machineName !== 'string' || !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(machineName)) {
    throw new BoxdVpsError('INVALID_MACHINE_NAME');
  }
  return {
    name: machineName,
    config: { vcpu: plan.vcpu, memory_bytes: String(plan.memoryBytes) },
  };
}

async function createMachineViaGrpc(apiKey, request, deps = {}) {
  if (typeof apiKey !== 'string' || !apiKey.trim()) throw new BoxdVpsError('BOXD_API_KEY_MISSING');
  let grpc;
  let protoLoader;
  try {
    grpc = deps.grpc || require('@grpc/grpc-js');
    protoLoader = deps.protoLoader || require('@grpc/proto-loader');
  } catch {
    throw new BoxdVpsError('BOXD_GRPC_DEPENDENCY_MISSING');
  }
  const fetchFn = deps.fetch || global.fetch;
  if (typeof fetchFn !== 'function') throw new BoxdVpsError('BOXD_AUTH_UNAVAILABLE');

  let tokenResponse;
  try {
    tokenResponse = await fetchFn(AUTH_ENDPOINT, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ api_key: apiKey }),
      signal: AbortSignal.timeout(15_000),
    });
  } catch {
    throw new BoxdVpsError('BOXD_AUTH_UNAVAILABLE');
  }
  if (!tokenResponse.ok) throw new BoxdVpsError('BOXD_AUTH_REJECTED');

  let token;
  try {
    const body = await tokenResponse.json();
    token = typeof body?.token === 'string' ? body.token : '';
  } catch {
    throw new BoxdVpsError('BOXD_AUTH_REJECTED');
  }
  if (!token) throw new BoxdVpsError('BOXD_AUTH_REJECTED');

  let client;
  try {
    const definition = protoLoader.loadSync(PROTO_PATH, {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true,
    });
    const api = grpc.loadPackageDefinition(definition).boxd.api.v1;
    client = new api.BoxdApi(GRPC_ENDPOINT, grpc.credentials.createSsl());
    const metadata = new grpc.Metadata();
    metadata.set('authorization', `Bearer ${token}`);
    return await new Promise((resolve, reject) => {
      client.CreateVm(request, metadata, (error, response) => {
        if (error) return reject(new BoxdVpsError('BOXD_CREATE_FAILED'));
        resolve(response);
      });
    });
  } catch (error) {
    if (error instanceof BoxdVpsError) throw error;
    throw new BoxdVpsError('BOXD_CREATE_FAILED');
  } finally {
    if (client) {
      try { client.close(); } catch {}
    }
    token = '';
  }
}

async function createBoxdMachine({ apiKey, customDomain, planId, createMachine }) {
  const { domain, machineName } = normalizeCustomDomain(customDomain);
  const plan = getBoxdPlan(planId);
  const request = buildCreateRequest({ machineName, planId });
  const adapter = createMachine || ((input) => createMachineViaGrpc(apiKey, input));
  const response = await adapter(request);
  const publicIp = response?.public_ip;
  const boxdUrl = response?.url;
  const dns = buildDnsInstructions({ customDomain: domain, publicIp, boxdUrl });
  return Object.freeze({
    machineName,
    domain,
    plan,
    status: String(response?.status || 'unknown'),
    publicIp,
    boxdUrl,
    dns,
  });
}

function formatCreatedMessage(result) {
  const domainLabels = result.domain.split('.');
  const hostLabel = domainLabels[0];
  const parentDomain = domainLabels.slice(1).join('.');
  return [
    'Boxd VPS creation accepted.',
    `Machine: ${result.machineName} · ${result.plan.vcpu} vCPU / ${result.plan.memoryGiB} GiB · status: ${result.status}`,
    `Boxd hostname: ${result.dns.boxdHostname}`,
    '',
    'Add these records at your DNS provider (use the full names below, or relative labels if your DNS editor auto-appends the zone):',
    `A  ${result.dns.aRecord.name}  →  ${result.dns.aRecord.target}`,
    `CNAME  ${result.dns.cnameRecord.name}  →  ${result.dns.cnameRecord.target}`,
    `If your DNS zone is ${parentDomain}, the relative host labels are A ${hostLabel} and CNAME *.${hostLabel}. Otherwise use the full names or the relative labels required by your zone.`,
    '',
    'The A target is Boxd’s shared proxy IP. This bot did not edit DNS or attach the custom domain. Once DNS is live, add/bind the domain in Boxd so it can verify the records and issue TLS. Check Boxd before retrying if the machine is not reachable yet; DNS is created when the machine boots.',
  ].join('\n');
}

function formatCreateError(error) {
  const code = error?.code || '';
  if (code === 'BOXD_API_KEY_MISSING') return 'Boxd VPS creation is not configured: set BOXD_API_KEY in the bot server environment. Never send the key in Telegram.';
  if (code === 'BOXD_AUTH_REJECTED') return 'Boxd authentication failed. Check the server-side BOXD_API_KEY; it was not shown or logged by the bot.';
  if (code === 'BOXD_GRPC_DEPENDENCY_MISSING') return 'Boxd VPS creation is unavailable because its gRPC dependencies are not installed.';
  if (code === 'BOXD_RESPONSE_MISSING_IP' || code === 'BOXD_RESPONSE_MISSING_HOSTNAME' || code === 'BOXD_RESPONSE_INVALID_HOSTNAME') {
    return 'Boxd accepted a create request but did not return the documented IP/hostname fields. Check the Boxd console before retrying; the bot will not create a duplicate automatically.';
  }
  if (code === 'BOXD_CREATE_FAILED' || code === 'BOXD_AUTH_UNAVAILABLE') {
    return 'Boxd did not confirm the result. A connection failure may happen after a create request was applied, so check the Boxd console before retrying. The bot will not retry automatically.';
  }
  return 'The Boxd VPS request could not be completed. No automatic retry was made.';
}

module.exports = {
  AUTH_ENDPOINT,
  BOXD_PLANS,
  BoxdVpsError,
  buildCreateRequest,
  buildDnsInstructions,
  createBoxdMachine,
  createMachineViaGrpc,
  formatCreatedMessage,
  formatCreateError,
  formatPlanChoice,
  formatPlanConfirmation,
  getBoxdPlan,
  normalizeCustomDomain,
};
