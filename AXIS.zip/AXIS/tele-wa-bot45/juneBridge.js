'use strict';
/**
 * juneBridge — mounts the JUNE-X ULTRA command pack (june/) inside this bot,
 * with per-number data isolation.
 *
 * Every message is dispatched inside an AsyncLocalStorage scope keyed by the
 * paired number (sock.user.id), so june/database and june/data resolve to
 * june/{database,data}/numbers/<number>/ for that session only.
 */
const path = require('path');

global.__CORE__ = path.join(__dirname, 'june');
global.__ROOT__ = path.join(__dirname, 'june');

// installs the per-number fs remap BEFORE the June modules are loaded
const sessionFs = require('./june/sessionFs');

let _handler = null;

function load() {
  if (!_handler) {
    _handler = require('./june/handler');
    console.log(`[june] command pack mounted — ${_handler.getCommandCount()} commands`);
  }
  return _handler;
}

module.exports = {
  async handle(sock, msg) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try {
        return await load().handleMessage(sock, msg);
      } catch (e) {
        console.error('[june] handler error:', e && e.message);
      }
    });
  },
  handleGroupUpdate(sock, update) {
    const session = sessionFs.sessionFromSock(sock) || 'default';
    return sessionFs.runWithSession(session, async () => {
      try { return load().handleGroupUpdate(sock, update); } catch (e) {
        console.error('[june] group update error:', e && e.message);
      }
    });
  },
  initAntiCall(sock) {
    try { return load().initializeAntiCall(sock); } catch (e) {
      console.error('[june] anticall error:', e && e.message);
    }
  },
  get count() {
    try { return load().getCommandCount(); } catch { return 0; }
  },
  preload() { load(); },
};
