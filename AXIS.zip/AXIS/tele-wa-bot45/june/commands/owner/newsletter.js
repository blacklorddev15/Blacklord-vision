/**
 * Newsletter Command - Get newsletter information from WhatsApp channel link
 */

const {
  sendButtons
} = require('gifted-btns');
function getChannelInviteCode(link) {
  try {
    let cleanLink = link.trim();
    cleanLink = cleanLink.split('?')[0].split('#')[0];
    try {
      const url = new URL(cleanLink);
      const parts = url.pathname.split('/').filter(Boolean);
      const code = parts[parts.length - 1];
      if (code && code.length > 0) return code;
    } catch (urlError) {}
    const patterns = [/(?:whatsapp\.com|wa\.me)\/channel\/([A-Za-z0-9]+)/i, /\/channel\/([A-Za-z0-9]+)/i, /channel\/([A-Za-z0-9]+)/i];
    for (const pattern of patterns) {
      const match = cleanLink.match(pattern);
      if (match && match[1]) return match[1];
    }
    if (/^[A-Za-z0-9]+$/.test(cleanLink)) return cleanLink;
    return null;
  } catch (error) {
    console.error('Error extracting invite code:', error);
    return null;
  }
}
module.exports = {
  name: 'newsletter',
  aliases: ['channel', 'channelinfo', 'nl'],
  category: 'owner',
  description: 'Get newsletter information from WhatsApp channel link',
  usage: '.newsletter <channel link>',
  ownerOnly: true,
  async execute(sock, msg, args, extra) {
    try {
      const chatId = extra.from;
      let link = args && args.length > 0 ? args.join(' ').trim() : '';
      if (!link) {
        return extra.reply('❌ Please provide a WhatsApp channel link!\n\nExample: .newsletter https://whatsapp.com/channel/0029VaAbCdEfGhIJkL');
      }
      const inviteCode = getChannelInviteCode(link);
      if (!inviteCode) {
        return extra.reply('❌ Could not extract invite code from the link!\n\nPlease provide a valid WhatsApp channel link.\nExample: https://whatsapp.com/channel/0029VaAbCdEfGhIJkL\n\nOr just the invite code: .newsletter 0029VaAbCdEfGhIJkL');
      }
      link = inviteCode;
      try {
        const meta = await sock.newsletterMetadata('invite', link);
        if (!meta) throw new Error('Newsletter not found');
        const finalInvite = meta.invite || inviteCode;
        const channelUrl = `https://whatsapp.com/channel/${finalInvite}`;
        let infoText = `┏━━『 *NEWSLETTER INFO* 』━━\n\n` + `🆔 *ID:* ${meta.id || 'N/A'}\n`;
        if (meta.name) infoText += `📛 *Name:* ${meta.name}\n`;
        if (meta.description) infoText += `📝 *Description:* ${meta.description}\n`;
        if (meta.invite) infoText += `🔗 *Invite Code:* ${meta.invite}\n`;
        if (meta.subscriberCount !== undefined) infoText += `👥 *Subscribers:* ${meta.subscriberCount.toLocaleString()}\n`;
        if (meta.creationTime) {
          const date = new Date(meta.creationTime * 1000);
          infoText += `📅 *Created:* ${date.toLocaleDateString()} ${date.toLocaleTimeString()}\n`;
        }
        infoText += `\n┗━━━━━━━━━━━━━━━━`;
        const buttons = [{
          name: 'cta_url',
          buttonParamsJson: JSON.stringify({
            display_text: '🌐 Open Channel',
            url: channelUrl
          })
        }, {
          name: 'cta_copy',
          buttonParamsJson: JSON.stringify({
            display_text: '🔑 Copy Newsletter',
            copy_code: meta.id
          })
        }];
        if (meta.image) {
          await sock.sendMessage(chatId, {
            image: {
              url: meta.image
            },
            caption: infoText
          }, {
            quoted: msg
          });
          await sendButtons(sock, chatId, {
            text: '> Use the buttons below:',
            footer: '> Newsletter Info',
            buttons
          }, {
            quoted: msg
          });
        } else {
          await sendButtons(sock, chatId, {
            text: infoText,
            footer: '> Newsletter Info',
            buttons
          }, {
            quoted: msg
          });
        }
      } catch (error) {
        console.error('Newsletter command error:', error);
        if (error.message.includes('Invalid channel link')) {
          await extra.reply('❌ Invalid channel link format!\n\nPlease provide a valid WhatsApp channel link.\nExample: https://whatsapp.com/channel/0029VaAbCdEfGhIJkL');
        } else if (error.message.includes('Newsletter not found')) {
          await extra.reply('❌ Newsletter not found!\n\nThe channel link might be invalid or the newsletter might not exist.');
        } else if (error.message.includes('newsletterMetadata')) {
          await extra.reply('❌ Newsletter feature not available!\n\nMake sure you are using Baileys v7.0.0-rc or higher.');
        } else {
          await extra.reply(`❌ Failed to get newsletter information: ${error.message}`);
        }
      }
    } catch (error) {
      console.error('Newsletter command error:', error);
      await extra.reply(`❌ An error occurred: ${error.message}`);
    }
  }
};