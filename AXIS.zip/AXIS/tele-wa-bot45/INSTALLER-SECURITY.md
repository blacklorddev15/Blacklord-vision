# Staged secure Panel and Wings installer

## Install Panel first

In a private chat with the configured main-owner Telegram account, choose **Install Panel** or run `/installpanel`. The bot asks for confirmation before it creates a one-time HTTPS form. That form collects the VPS IP, SSH username, SSH port, SSH password, Panel domain, and the Panel administrator/contact details. It installs the Panel only; it does not install Wings in this step. Use a fresh VPS you control.

When the Panel installation succeeds, the bot sends the Panel URL and pauses. Sign in there, create a node and its allocations, then copy the complete generated `config.yml` from the node's Configuration tab.

## Create Wings after the node exists

Return to Telegram and choose **Create Wings** or run `/createwings`. The one-time HTTPS form asks for the target VPS IP, SSH username, SSH port, SSH password, node hostname, Let's Encrypt contact email, and the full node `config.yml`. It requires confirmation that the node has already been created. The bot installs Wings, writes the config to `/etc/pterodactyl/config.yml` on the target VPS, starts Wings, and checks that the service is active.

The SSH credentials are intentionally requested again for the Wings step; the bot discards them after each installation attempt and keeps no Panel/Wings phase credentials on disk. The configuration contains node credentials: it is accepted only in the HTTPS form, held in process memory during the SSH transfer, and written only to the required runtime file on the target VPS. It is not written to the bot host or its database, sent in Telegram, or included in status messages.

## Deployment and prerequisites

Set `INSTALL_FORM_BASE_URL` to the public HTTPS origin that serves the bot and configure `TRUST_PROXY_HOPS` for the trusted TLS reverse proxy. Do not expose port 3002 directly to the public internet; only the TLS-terminating proxy should reach it. Requests without HTTPS are rejected. Form links are owner-bound, single-use, expire after 10 minutes, and are held in memory, so a bot restart requires issuing a fresh link.

Before submitting each stage, point the corresponding hostname's DNS A record to the VPS and allow certificate-validation traffic. The Panel and Wings hostname should be distinct. When the Panel uses SSL, Wings needs a valid certificate for its node hostname; the installer requests Let's Encrypt for the node name. The firewall is left unchanged unless the owner opts in on the form. A non-root SSH user must be allowed to use `sudo` with the same password.

The automation downloads the pinned `v1.4.0` installer from the separate [pterodactyl-installer project](https://github.com/pterodactyl-installer/pterodactyl-installer), which is not affiliated with the official Pterodactyl project. Review upstream changes and use only a VPS you control.

All previously embedded credentials were removed from the working archive and are environment-only now. Credentials that were already present in the public repository history must still be rotated at their providers; editing current files does not revoke credentials or erase Git history.

## Create a Boxd VPS

In a private chat with the configured main owner account, run `/boxdvps`. The bot asks for a fully qualified subdomain you control (for example `panel.example.com`), derives the Boxd machine name from its first label (`panel`), and offers only the current protobuf-documented 1/4, 2/8, and 4/16 vCPU/GiB sizes. The pending request expires after 10 minutes; `/cancel` or the Cancel button discards it.

Before any provider create call, the bot shows the machine name, Frankfurt region, fixed 100 GiB disk, public EUR usage rates, maximum always-on rate-card estimate, VAT exclusion, and that the IP is a shared proxy address. Boxd charges by actual active CPU, memory in use, and disk written, so there is no fixed total. The organization is the one fenced to the server-side API key. Boxd's API-key session cannot read billing details; verify the intended organization, billing currency, and balance in the Boxd console. Only the configured main owner in a private chat can press **Confirm and create metered VPS**.

Set `BOXD_API_KEY` only in the bot server environment. It is exchanged over HTTPS for a short-lived token and sent as gRPC authorization metadata. Never send the key in Telegram or place it in source files. The bot does not retry ambiguous create failures automatically; check Boxd before retrying to avoid duplicates.

On success, the bot uses Boxd's returned `public_ip` for the A record and returned `url` hostname as the CNAME target. It prints the A record for the requested domain and the wildcard CNAME (`*.<domain>`) to the Boxd hostname. This does not change DNS or attach the custom domain. Add the records at your DNS host first, then bind/verify the domain in Boxd; see the [official custom-domain guide](https://docs.boxd.sh/guides/custom-domains). The machine's default Boxd hostname is available separately after it boots.

## Install the latest repo theme

In a private chat with the configured main owner account, run `/installtema`. The bot issues an owner-bound, single-use HTTPS link that expires after 10 minutes; enter the target Panel VPS SSH details and Panel directory there, not in Telegram. The bot fetches the allowlisted files from `signed-in-dashboard-theme/` in the public `blacklorddev15/theme` repository and checks the manifest's SHA-256 hashes and sizes before it connects over SSH.

The installer creates a private backup under `/var/backups/blacklord-theme/` (outside the Panel web root), installs the signed-in illustrated background, dark glass and yellow-green styling, bottom navigation, and the editable Theme & Branding page. It preserves an existing `public/panel-theme.json` and does not alter the current Company Name. The Company Name, background URL, and theme colors remain editable in Admin → Theme & Branding. It does not edit `resources/views/templates/auth/core.blade.php` or login assets. Unsupported Panel layouts fail closed; file changes are rolled back if installation or cache clearing fails.

The old theme buttons that embedded SSH credentials in Telegram callback data are inert. `/uninstalltema` is disabled and does not accept credentials; this update does not add theme-removal automation. The Panel → manual node → Create Wings sequence and the separate owner-only Boxd VPS option remain unchanged. Pixel WhatsApp command dispatch remains disabled in the current bundle.
