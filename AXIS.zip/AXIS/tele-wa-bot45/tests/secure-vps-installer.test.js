'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const {
  createInstallTokenStore,
  buildInstallFormUrl,
  isPublicIPv4,
  isValidHostname,
  validatePanelInstallInput,
  validateWingsInstallInput,
  buildPanelInstallScript,
  buildWingsInstallScript,
  renderInstallForm,
  runInstallerOverSSH,
  InstallerError,
} = require('../helper/secure-vps-installer');

const panelForm = {
  ip: '8.8.8.8',
  ssh_username: 'root',
  ssh_port: '2222',
  ssh_password: 'private-ssh-passphrase',
  panel_domain: 'panel.example.com',
  contact_email: 'owner@example.com',
  admin_email: 'admin@example.com',
  admin_username: 'paneladmin',
  admin_first_name: 'Ada',
  admin_last_name: 'Lovelace',
  admin_password: 'StrongExample92',
  confirm_fresh_server: 'on',
};

const wingsConfig = `debug: false
uuid: node-uuid
token_id: node-token-id
token: secret-marker
api:
  host: 0.0.0.0
system:
  data: /var/lib/pterodactyl/volumes
`;
const wingsForm = {
  ip: '8.8.8.8',
  ssh_username: 'root',
  ssh_port: '2222',
  ssh_password: 'private-ssh-passphrase',
  node_domain: 'node.example.com',
  contact_email: 'owner@example.com',
  wings_config: wingsConfig,
  confirm_node_created: 'on',
};

test('install tokens bind owner and stage, expire, and are single-use', () => {
  let now = 1_000;
  const store = createInstallTokenStore({ ttlMs: 500, now: () => now });
  const issued = store.issue('owner-1', 'panel');
  assert.match(issued.token, /^[a-f0-9]{64}$/);
  assert.equal(store.peek(issued.token).action, 'panel');
  assert.equal(store.consume(issued.token, 'owner-1', 'wings'), false);
  assert.equal(store.consume(issued.token, 'owner-2', 'panel'), false);
  assert.equal(store.consume(issued.token, 'owner-1', 'panel'), true);
  assert.equal(store.peek(issued.token), null);
  const second = store.issue('owner-1', 'wings');
  now += 501;
  assert.equal(store.peek(second.token), null);
  assert.equal(store.size(), 0);
});

test('form URL requires HTTPS and identifies the stage without exposing token in request path', () => {
  const link = new URL(buildInstallFormUrl('https://bot.example.com', 'a'.repeat(64), 'wings'));
  assert.equal(link.searchParams.get('action'), 'wings');
  assert.equal(link.hash, `#${'a'.repeat(64)}`);
  assert.equal(link.pathname, '/secure-panel-install');
  assert.throws(() => buildInstallFormUrl('http://bot.example.com', 'a'.repeat(64), 'panel'), InstallerError);
});

test('public IPv4 and hostnames reject private, reserved, or injected values', () => {
  assert.equal(isPublicIPv4('8.8.8.8'), true);
  for (const address of ['127.0.0.1', '10.0.0.8', '172.16.0.1', '192.168.1.1', '169.254.1.1', '203.0.113.10']) {
    assert.equal(isPublicIPv4(address), false);
  }
  assert.equal(isValidHostname('node.example.com'), true);
  assert.equal(isValidHostname('localhost'), false);
  assert.equal(isValidHostname('node.example.com;id'), false);
});

test('Panel form requires fresh-server consent and validates a custom SSH port', () => {
  assert.throws(() => validatePanelInstallInput({ ...panelForm, confirm_fresh_server: undefined }), /FRESH_SERVER_CONFIRMATION_REQUIRED/);
  const details = validatePanelInstallInput(panelForm);
  assert.equal(details.sshPort, 2222);
  assert.equal(details.panelDomain, 'panel.example.com');
  assert.equal(details.configureFirewall, false);
  assert.throws(() => validatePanelInstallInput({ ...panelForm, ssh_port: '70000' }), /INVALID_SSH_PORT/);
});

test('Wings form requires a created node and complete config without echoing config in the install script', () => {
  assert.throws(() => validateWingsInstallInput({ ...wingsForm, confirm_node_created: undefined }), /NODE_CONFIRMATION_REQUIRED/);
  const details = validateWingsInstallInput(wingsForm);
  assert.equal(details.nodeDomain, 'node.example.com');
  const script = buildWingsInstallScript(details);
  assert.match(script, /pterodactyl-installer\/v1\.4\.0\/install\.sh/);
  assert.match(script, /<<< '1'/);
  assert.match(script, /\/etc\/pterodactyl\/config\.yml/);
  assert.match(script, /systemctl enable --now wings/);
  assert.doesNotMatch(script, /secret-marker/);
});

test('Panel script installs Panel only; Wings waits for the later Create Wings action', () => {
  const details = validatePanelInstallInput(panelForm);
  const script = buildPanelInstallScript(details);
  assert.match(script, /export FQDN='panel\.example\.com'/);
  assert.match(script, /export CONFIGURE_LETSENCRYPT=true/);
  assert.match(script, /<<< '0'/);
  assert.doesNotMatch(script, /<<< '1'/);
  const firewallScript = buildPanelInstallScript(validatePanelInstallInput({ ...panelForm, configure_firewall: 'on' }));
  assert.match(firewallScript, /ufw allow 2222\/tcp/);
});

test('the form renders stage-specific fields, uses the URL fragment, and loads no third-party assets', () => {
  const panelHtml = renderInstallForm('nonce-value', 'panel');
  const wingsHtml = renderInstallForm('nonce-value', 'wings');
  assert.match(panelHtml, /name="ssh_port"/);
  assert.match(panelHtml, /name="panel_domain"/);
  assert.doesNotMatch(panelHtml, /name="wings_config"/);
  assert.match(wingsHtml, /name="wings_config"/);
  assert.match(wingsHtml, /name="confirm_node_created"/);
  assert.match(wingsHtml, /written only on the target VPS/i);
  for (const html of [panelHtml, wingsHtml]) {
    assert.match(html, /history\.replaceState/);
    assert.match(html, /nonce="nonce-value"/);
    assert.doesNotMatch(html, /<script[^>]+src=/i);
  }
});

test('SSH runner uses the supplied port and clears secrets after the attempt', async () => {
  class FakeStream extends EventEmitter {
    constructor() { super(); this.stderr = new EventEmitter(); this.input = ''; }
    end(input) { this.input = input; setImmediate(() => this.emit('close', 0, null)); }
  }
  let fakeClient;
  class FakeClient extends EventEmitter {
    constructor() { super(); this.config = {}; fakeClient = this; }
    connect(config) { this.connectionOptions = config; setImmediate(() => this.emit('ready')); }
    exec(command, options, callback) { this.command = command; this.stream = new FakeStream(); callback(null, this.stream); }
    end() {}
  }
  const details = validateWingsInstallInput(wingsForm);
  const result = await runInstallerOverSSH(details, FakeClient, 'wings');
  assert.deepEqual(result, { exitCode: 0, action: 'wings' });
  assert.equal(fakeClient.connectionOptions.port, 2222);
  assert.equal(fakeClient.connectionOptions.password, '');
  assert.equal(fakeClient.command, 'bash -s');
  assert.doesNotMatch(fakeClient.stream.input, /secret-marker/);
  assert.equal(details.sshPassword, '');
  assert.equal(details.wingsConfig, '');
});
