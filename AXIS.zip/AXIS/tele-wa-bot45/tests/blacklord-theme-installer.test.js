'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const {
  ALLOWED_THEME_FILES,
  THEME_RAW_BASE,
  THEME_REPOSITORY,
  InstallerError,
  validateThemeInstallInput,
  validateThemeManifest,
  fetchThemeBundle,
  buildThemeInstallScript,
  renderInstallForm,
  runInstallerOverSSH,
} = require('../helper/secure-vps-installer');

const themeForm = {
  ip: '8.8.8.8',
  ssh_username: 'root',
  ssh_port: '27140',
  ssh_password: 'private-ssh-passphrase',
  panel_root: '/var/www/pterodactyl',
  confirm_theme_install: 'on',
};

function makeSource() {
  const files = Object.fromEntries(ALLOWED_THEME_FILES.map((name) => [name, Buffer.from(`fixture:${name}`)]));
  const manifest = {
    name: 'Blacklord Signed-in Theme',
    repository: 'blacklorddev15/theme',
    version: '2026.11.17.1',
    files: Object.fromEntries(Object.entries(files).map(([name, data]) => [name, {
      size: data.length,
      sha256: crypto.createHash('sha256').update(data).digest('hex'),
    }])),
  };
  return { files, manifest, manifestBuffer: Buffer.from(JSON.stringify(manifest)) };
}

function bundleFetcher(source) {
  return async (url) => {
    if (url === `${THEME_RAW_BASE}/manifest.json`) return source.manifestBuffer;
    const relative = url.slice(`${THEME_RAW_BASE}/`.length);
    const name = decodeURIComponent(relative);
    if (!source.files[name]) throw new Error('unexpected file request');
    return source.files[name];
  };
}

test('theme form validates a public Panel VPS, restricted Panel path, and explicit approval', () => {
  const details = validateThemeInstallInput(themeForm);
  assert.equal(details.host, '8.8.8.8');
  assert.equal(details.sshPort, 27140);
  assert.equal(details.panelRoot, '/var/www/pterodactyl');
  assert.throws(() => validateThemeInstallInput({ ...themeForm, confirm_theme_install: undefined }), /THEME_INSTALL_CONFIRMATION_REQUIRED/);
  assert.throws(() => validateThemeInstallInput({ ...themeForm, panel_root: '/var/www/../etc' }), /INVALID_PANEL_ROOT/);
  assert.throws(() => validateThemeInstallInput({ ...themeForm, panel_root: 'https://example.com' }), /INVALID_PANEL_ROOT/);
});

test('theme manifest is limited to the intended repo and exact allowlisted package files', () => {
  const source = makeSource();
  assert.equal(THEME_REPOSITORY, 'blacklorddev15/theme');
  assert.equal(THEME_RAW_BASE, 'https://raw.githubusercontent.com/blacklorddev15/theme/main/signed-in-dashboard-theme');
  assert.equal(validateThemeManifest(source.manifestBuffer).version, '2026.11.17.1');
  const tampered = { ...source.manifest, repository: 'someone-else/Other' };
  assert.throws(() => validateThemeManifest(tampered), /THEME_MANIFEST_INVALID/);
  const extraFile = { ...source.manifest, files: { ...source.manifest.files, '../secret': { size: 1, sha256: 'a'.repeat(64) } } };
  assert.throws(() => validateThemeManifest(extraFile), /THEME_FILE_LIST_INVALID/);
});

test('theme downloader fetches only allowlisted raw GitHub files and verifies every digest', async () => {
  const source = makeSource();
  const bundle = await fetchThemeBundle({ getBuffer: bundleFetcher(source) });
  assert.equal(bundle.manifest.version, source.manifest.version);
  assert.deepEqual(Object.keys(bundle.files).sort(), [...ALLOWED_THEME_FILES].sort());
  await assert.rejects(
    fetchThemeBundle({ getBuffer: bundleFetcher(source), baseUrl: 'https://evil.example/theme' }),
    /THEME_SOURCE_URL_REJECTED/,
  );
  await assert.rejects(
    fetchThemeBundle({ getBuffer: bundleFetcher(source), baseUrl: 'https://raw.githubusercontent.com/blacklorddev15/Blacklord-vision/main/theme' }),
    /THEME_SOURCE_URL_REJECTED/,
  );
  const corrupted = makeSource();
  corrupted.files['assets/james-admin.css'] = Buffer.from('tampered');
  await assert.rejects(fetchThemeBundle({ getBuffer: bundleFetcher(corrupted) }), /THEME_INTEGRITY_FAILED/);
});

test('theme script streams verified package bytes to a temporary target and excludes SSH credentials', () => {
  const source = makeSource();
  const bundle = { manifest: source.manifest, manifestBuffer: source.manifestBuffer, files: source.files };
  const details = validateThemeInstallInput(themeForm);
  const script = buildThemeInstallScript(details, bundle);
  assert.match(script, /mktemp -d \/tmp\/blacklord-theme/);
  assert.match(script, /install-theme\.py/);
  assert.match(script, /\/var\/www\/pterodactyl/);
  assert.match(script, /base64 --decode/);
  assert.doesNotMatch(script, /private-ssh-passphrase/);
  assert.doesNotMatch(script, /curl .*\|.*bash/);
  assert.throws(() => buildThemeInstallScript(details, { ...bundle, files: {} }), InstallerError);
});

test('theme form explains the repo source, preservation behavior, and login isolation', () => {
  const html = renderInstallForm('nonce-value', 'theme');
  assert.match(html, /name="panel_root"/);
  assert.match(html, /name="confirm_theme_install"/);
  assert.match(html, /SHA-256/i);
  assert.match(html, /Existing Company Name, background URL, and colors are preserved/i);
  assert.match(html, /authentication\/login templates and login assets are not changed/i);
  assert.match(html, /history\.replaceState/);
  assert.match(html, /nonce="nonce-value"/);
});

test('SSH runner clears theme credentials and downloaded bytes after the attempt', async () => {
  class FakeStream extends EventEmitter {
    constructor() { super(); this.stderr = new EventEmitter(); this.input = ''; }
    end(input) { this.input = input; setImmediate(() => this.emit('close', 0, null)); }
  }
  let fakeClient;
  class FakeClient extends EventEmitter {
    constructor() { super(); this.config = {}; fakeClient = this; }
    connect(config) { this.connectionOptions = config; setImmediate(() => this.emit('ready')); }
    exec(command, options, callback) { this.command = command; this.stream = new FakeStream(); callback(null, this.stream); }
    end() {}
  }
  const source = makeSource();
  const bundle = { manifest: source.manifest, manifestBuffer: source.manifestBuffer, files: source.files };
  const details = validateThemeInstallInput(themeForm);
  const result = await runInstallerOverSSH(details, FakeClient, 'theme', bundle);
  assert.deepEqual(result, { exitCode: 0, action: 'theme' });
  assert.equal(fakeClient.connectionOptions.port, 27140);
  assert.equal(fakeClient.connectionOptions.password, '');
  assert.equal(fakeClient.command, 'bash -s');
  assert.match(fakeClient.stream.input, /blacklord-theme\.XXXXXX/);
  assert.doesNotMatch(fakeClient.stream.input, /private-ssh-passphrase/);
  assert.equal(details.sshPassword, '');
  assert.equal(bundle.manifestBuffer.every((value) => value === 0), true);
  assert.equal(Object.values(bundle.files).every((data) => data.every((value) => value === 0)), true);
});
