'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  AUTH_ENDPOINT,
  BOXD_PLANS,
  BoxdVpsError,
  buildCreateRequest,
  buildDnsInstructions,
  createBoxdMachine,
  createMachineViaGrpc,
  formatCreateError,
  formatCreatedMessage,
  formatPlanChoice,
  formatPlanConfirmation,
  normalizeCustomDomain,
} = require('../helper/boxd-vps');

test('custom domain is validated and its first hostname label becomes the Boxd machine name', () => {
  assert.deepEqual(normalizeCustomDomain('Panel.Example.com.'), {
    domain: 'panel.example.com',
    machineName: 'panel',
  });
  assert.throws(() => normalizeCustomDomain('example.com'), (error) => error.code === 'SUBDOMAIN_REQUIRED');
  for (const bad of ['https://panel.example.com', 'localhost', 'bad name.example.com', 'x..example.com', '-node.example.com']) {
    assert.throws(() => normalizeCustomDomain(bad), BoxdVpsError);
  }
});

test('only API-documented, unambiguous size classes are offered with their public EUR maxima', () => {
  assert.deepEqual(Object.keys(BOXD_PLANS), ['1', '2', '4']);
  assert.equal(formatPlanChoice('1'), '1 vCPU · 4 GiB — up to €0.10/hour');
  assert.equal(BOXD_PLANS['2'].maxMonthlyEUR, '€132.86');
  assert.throws(() => formatPlanChoice('8'), (error) => error.code === 'INVALID_PLAN');
});

test('create request contains only the documented name and size fields, leaving fixed disk defaults intact', () => {
  assert.deepEqual(buildCreateRequest({ machineName: 'panel', planId: '2' }), {
    name: 'panel',
    config: { vcpu: 2, memory_bytes: String(8 * 1024 ** 3) },
  });
  assert.throws(() => buildCreateRequest({ machineName: 'bad.name', planId: '2' }), (error) => error.code === 'INVALID_MACHINE_NAME');
});

test('mocked create response supplies the public IP for A and API hostname for CNAME', async () => {
  let calls = 0;
  let requestSeen;
  const result = await createBoxdMachine({
    apiKey: 'must-not-be-forwarded-to-telegram',
    customDomain: 'panel.example.com',
    planId: '1',
    createMachine: async (request) => {
      calls += 1;
      requestSeen = request;
      return { name: 'panel', public_ip: '8.8.8.8', url: 'https://panel.boxd.sh', status: 'starting' };
    },
  });
  assert.equal(calls, 1);
  assert.deepEqual(requestSeen, { name: 'panel', config: { vcpu: 1, memory_bytes: String(4 * 1024 ** 3) } });
  assert.deepEqual(result.dns.aRecord, { name: 'panel.example.com', type: 'A', target: '8.8.8.8' });
  assert.deepEqual(result.dns.cnameRecord, { name: '*.panel.example.com', type: 'CNAME', target: 'panel.boxd.sh' });
  assert.match(formatCreatedMessage(result), /If your DNS zone is example\.com, the relative host labels are A panel and CNAME \*\.panel/);
  assert.equal(result.status, 'starting');
});

test('missing or malformed public IP/hostname is not guessed after create', async () => {
  await assert.rejects(createBoxdMachine({
    apiKey: 'mock-only', customDomain: 'panel.example.com', planId: '1',
    createMachine: async () => ({ public_ip: '', url: 'https://panel.boxd.sh' }),
  }), (error) => error.code === 'BOXD_RESPONSE_MISSING_IP');
  await assert.rejects(createBoxdMachine({
    apiKey: 'mock-only', customDomain: 'panel.example.com', planId: '1',
    createMachine: async () => ({ public_ip: '8.8.8.8', url: 'not a hostname' }),
  }), (error) => error.code === 'BOXD_RESPONSE_INVALID_HOSTNAME');
});

test('confirmation discloses plan, variable cost terms, shared IP, EUR/VAT caveat and requires human approval', () => {
  const text = formatPlanConfirmation({ domain: 'panel.example.com', machineName: 'panel', planId: '4' });
  assert.match(text, /4 vCPU, 16 GiB RAM, fixed 100 GiB disk/);
  assert.match(text, /€0\.36\/hour/);
  assert.match(text, /€0\.039 per active vCPU-hour/);
  assert.match(text, /Billing organization: the organization fenced to the server-side BOXD_API_KEY/);
  assert.match(text, /verify the target organization, currency, and balance/);
  assert.match(text, /shared proxy IP, not a dedicated machine IP/);
  assert.match(text, /VAT excluded/);
  assert.match(text, /Tap Confirm only/);
  assert.doesNotMatch(text, /must-not-be-forwarded-to-telegram/);
});

test('error text never leaks an API key or raw upstream error', () => {
  assert.match(formatCreateError({ code: 'BOXD_API_KEY_MISSING' }), /server environment/);
  assert.match(formatCreateError({ code: 'BOXD_CREATE_FAILED', message: 'Bearer super-secret' }), /will not retry automatically/);
  assert.doesNotMatch(formatCreateError({ code: 'BOXD_CREATE_FAILED', message: 'Bearer super-secret' }), /super-secret/);
});


test('gRPC adapter exchanges the server key and calls CreateVm with a mocked client only', async () => {
  const calls = { fetch: 0, endpoint: '', metadata: null, request: null, closed: false, protoPath: '' };
  class MockClient {
    constructor(endpoint, credentials) {
      calls.endpoint = endpoint;
      assert.equal(credentials, 'mock-tls');
    }
    CreateVm(request, metadata, callback) {
      calls.request = request;
      calls.metadata = metadata.values;
      callback(null, { name: 'panel', public_ip: '8.8.8.8', url: 'https://panel.boxd.sh', status: 'starting' });
    }
    close() { calls.closed = true; }
  }
  class MockMetadata {
    constructor() { this.values = {}; }
    set(name, value) { this.values[name] = value; }
  }
  const grpc = {
    Metadata: MockMetadata,
    credentials: { createSsl: () => 'mock-tls' },
    loadPackageDefinition: () => ({ boxd: { api: { v1: { BoxdApi: MockClient } } } }),
  };
  const protoLoader = {
    loadSync(protoPath, options) {
      calls.protoPath = protoPath;
      assert.equal(options.keepCase, true);
      return { mocked: true };
    },
  };

  const response = await createMachineViaGrpc('mock-api-key', {
    name: 'panel',
    config: { vcpu: 1, memory_bytes: String(4 * 1024 ** 3) },
  }, {
    grpc,
    protoLoader,
    fetch: async (url, options) => {
      calls.fetch += 1;
      assert.equal(url, AUTH_ENDPOINT);
      assert.equal(options.method, 'POST');
      assert.deepEqual(JSON.parse(options.body), { api_key: 'mock-api-key' });
      return { ok: true, json: async () => ({ token: 'mock-jwt' }) };
    },
  });

  assert.equal(calls.fetch, 1);
  assert.equal(calls.endpoint, 'boxd.sh:9443');
  assert.equal(calls.metadata.authorization, 'Bearer mock-jwt');
  assert.deepEqual(calls.request, { name: 'panel', config: { vcpu: 1, memory_bytes: String(4 * 1024 ** 3) } });
  assert.match(calls.protoPath, /boxd-create-vm\.proto$/);
  assert.equal(calls.closed, true);
  assert.deepEqual(response, { name: 'panel', public_ip: '8.8.8.8', url: 'https://panel.boxd.sh', status: 'starting' });
});
