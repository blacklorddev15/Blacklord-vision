'use strict';

// Pixel WhatsApp command handling is intentionally disabled in this build.
// The WhatsApp connection/runtime remains in index.js; this compatibility module
// deliberately dispatches no commands or automatic actions.
const CMDS = Object.freeze([]);
const ALL_CMDS = Object.freeze([]);
const DISABLED = 'Pixel WhatsApp commands are disabled in this build.';

async function handleMessage() {
  return false;
}

async function runAutoFollow() {
  return false;
}

function renderMenu() {
  return DISABLED;
}

function pixelMenuReport() {
  return DISABLED;
}

module.exports = { handleMessage, runAutoFollow, CMDS, renderMenu, pixelMenuReport, ALL_CMDS };
